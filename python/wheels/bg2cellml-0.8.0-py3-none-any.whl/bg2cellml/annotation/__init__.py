"""

@prefix circ: <./circulation.ttl#> .
@prefix gi-tract: <./gi-tract.ttl#> .
@prefix kidney: <./kidney.ttl#> .


* https://github.com/combine-org/combine-specifications/blob/main/specifications/qualifiers-1.1.md
* https://www.degruyterbrill.com/document/doi/10.1515/jib-2021-0020/html


bio: <http://biomodels.net/biology-qualifiers/>
* https://dbrnz.github.io/ontologies/biomodels-biology-qualifiers

    "bio:encodes",
    "bio:hasPart",
    "bio:hasProperty",
    "bio:hasVersion",
    "bio:is",
    "bio:isDescribedBy",
    "bio:isEncodedBy",
    "bio:isHomologTo",
    "bio:isPartOf",
    "bio:isPropertyOf",
    "bio:isVersionOf",
    "bio:occursIn",
    "bio:hasTaxon",

model: http://biomodels.net/model-qualifiers/
https://dbrnz.github.io/ontologies/biomodels-model-qualifiers

    "model:is",
    "model:isDerivedFrom",
    "model:isDescribedBy",
    "model:isInstanceOf",
    "model:hasInstance"

    <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
        <!--i_of_v_in_e-->
        <rdf:Description rdf:about="#id_000000001">
            <is xmlns="http://biomodels.net/biology-qualifiers/">
                <rdf:Description rdf:about="http://identifiers.org/opb/OPB_01196"/>
            </is>
        </rdf:Description>
        <!--i_of_v_out_e-->
        <rdf:Description rdf:about="#id_000000002">
            <is xmlns="http://biomodels.net/biology-qualifiers/">
                <rdf:Description rdf:about="http://bhi.washington.edu/OPB#OPB01530"/>
            </is>
        </rdf:Description>
        <!--p_of_L-->
        <rdf:Description rdf:about="#id_000000003">
            <is xmlns="http://biomodels.net/biology-qualifiers/">
                <rdf:Description rdf:about="http://identifiers.org/opb/OPB_00006"/>
            </is>
        </rdf:Description>
        <!--q_of_C_q_C_e-->
        <rdf:Description rdf:about="#id_000000004">
            <is xmlns="http://biomodels.net/biology-qualifiers/">
                <rdf:Description rdf:about="http://identifiers.org/opb/OPB_01219"/>
            </is>
        </rdf:Description>
        <!--r_of_R-->
        <rdf:Description rdf:about="#id_000000005">
            <is xmlns="http://biomodels.net/biology-qualifiers/">
                <rdf:Description rdf:about="http://identifiers.org/opb/OPB_00151"/>
            </is>
        </rdf:Description>
    </rdf:RDF>


"""
